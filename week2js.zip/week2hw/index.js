function IlearnJs(){
console.log("Я учу Java Script !");
}
IlearnJs();