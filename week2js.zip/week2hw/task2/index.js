function nextSlide() {
  document.querySelector("img").src = "./style/images/cat1.jpg";
}

function PrevSlider() {
  document.querySelector("img").src = "./style/images/cat2.webp";
}

let sliderBtnPrev = document.querySelector(".btn__1-prev");
let sliderBtnNext = document.querySelector(".btn__1-next");

sliderBtnPrev.addEventListener("click", PrevSlider);
sliderBtnNext.addEventListener("click", nextSlide);
